const STORAGE_KEY = "mycalendar.state.v1";

const calendarModes = {
  islamicSaturday: {
    label: "Islamic calendar",
    caption: "Islamic calendar - week starts Saturday",
    weekStart: 6,
    islamic: true
  },
  european: {
    label: "European calendar",
    caption: "European calendar - week starts Monday",
    weekStart: 1,
    islamic: false
  },
  northAmerican: {
    label: "North American calendar",
    caption: "North American calendar - week starts Sunday",
    weekStart: 0,
    islamic: false
  }
};

const weekdayNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const monthFormatter = new Intl.DateTimeFormat("en", { month: "long", year: "numeric" });
const dateHeadingFormatter = new Intl.DateTimeFormat("en", {
  weekday: "long",
  month: "long",
  day: "numeric",
  year: "numeric"
});

const islamicFormatter = buildFormatter("en-u-ca-islamic", {
  month: "short",
  day: "numeric",
  year: "numeric"
});

const islamicShortFormatter = buildFormatter("en-u-ca-islamic", {
  month: "short",
  day: "numeric"
});

const shortDayFormatter = new Intl.DateTimeFormat("en", { weekday: "short" });

const weatherCodes = {
  0: ["Sunny", "sun"],
  1: ["Mostly sunny", "sun"],
  2: ["Partly cloudy", "cloud"],
  3: ["Cloudy", "cloud"],
  45: ["Foggy", "fog"],
  48: ["Foggy", "fog"],
  51: ["Light drizzle", "rain"],
  53: ["Drizzle", "rain"],
  55: ["Heavy drizzle", "rain"],
  56: ["Freezing drizzle", "rain"],
  57: ["Freezing drizzle", "rain"],
  61: ["Light rain", "rain"],
  63: ["Rainy", "rain"],
  65: ["Heavy rain", "rain"],
  66: ["Freezing rain", "rain"],
  67: ["Freezing rain", "rain"],
  71: ["Light snow", "snow"],
  73: ["Snowy", "snow"],
  75: ["Heavy snow", "snow"],
  77: ["Snow grains", "snow"],
  80: ["Rain showers", "rain"],
  81: ["Rain showers", "rain"],
  82: ["Heavy showers", "rain"],
  85: ["Snow showers", "snow"],
  86: ["Snow showers", "snow"],
  95: ["Thunderstorm", "storm"],
  96: ["Thunderstorm", "storm"],
  99: ["Thunderstorm", "storm"]
};

let state = loadState();
let selectedUserId = state.activeUserId || null;
let activeUserId = state.activeUserId || null;
let viewDate = startOfMonth(new Date());
let selectedDate = new Date();
let pendingNewUserAvatar = "";
let clockTimer = null;

const loginScreen = document.querySelector("#loginScreen");
const appScreen = document.querySelector("#appScreen");
const userSlots = document.querySelector("#userSlots");
const loginForm = document.querySelector("#loginForm");
const selectedAvatarFrame = document.querySelector("#selectedAvatarFrame");
const selectedUserName = document.querySelector("#selectedUserName");
const selectedPasswordPrompt = document.querySelector("#selectedPasswordPrompt");
const passwordInput = document.querySelector("#passwordInput");
const hintButton = document.querySelector("#hintButton");
const hintBubble = document.querySelector("#hintBubble");
const hintText = document.querySelector("#hintText");
const loginImageInput = document.querySelector("#loginImageInput");
const removeProfileButton = document.querySelector("#removeProfileButton");
const loginMessage = document.querySelector("#loginMessage");
const createUserForm = document.querySelector("#createUserForm");
const newUserName = document.querySelector("#newUserName");
const newUserPassword = document.querySelector("#newUserPassword");
const newUserHint = document.querySelector("#newUserHint");
const newUserImage = document.querySelector("#newUserImage");
const createUserButton = document.querySelector("#createUserButton");
const createMessage = document.querySelector("#createMessage");
const profileCount = document.querySelector("#profileCount");
const workspaceTitle = document.querySelector("#workspaceTitle");
const activeAvatarFrame = document.querySelector("#activeAvatarFrame");
const activeUserName = document.querySelector("#activeUserName");
const activeImageInput = document.querySelector("#activeImageInput");
const calendarMode = document.querySelector("#calendarMode");
const signOutButton = document.querySelector("#signOutButton");
const selectedDateHeading = document.querySelector("#selectedDateHeading");
const alternateDate = document.querySelector("#alternateDate");
const planCount = document.querySelector("#planCount");
const reminderCount = document.querySelector("#reminderCount");
const waterCount = document.querySelector("#waterCount");
const upcomingList = document.querySelector("#upcomingList");
const clockText = document.querySelector("#clockText");
const digitalClock = document.querySelector("#digitalClock");
const clockDate = document.querySelector("#clockDate");
const clockHourHand = document.querySelector("#clockHourHand");
const clockMinuteHand = document.querySelector("#clockMinuteHand");
const enableAlertsButton = document.querySelector("#enableAlertsButton");
const weatherForm = document.querySelector("#weatherForm");
const weatherLocationInput = document.querySelector("#weatherLocationInput");
const weatherIcon = document.querySelector("#weatherIcon");
const weatherCondition = document.querySelector("#weatherCondition");
const weatherMeta = document.querySelector("#weatherMeta");
const weatherTemp = document.querySelector("#weatherTemp");
const weatherUnit = document.querySelector("#weatherUnit");
const weatherForecast = document.querySelector("#weatherForecast");
const weatherMessage = document.querySelector("#weatherMessage");
const modeCaption = document.querySelector("#modeCaption");
const monthTitle = document.querySelector("#monthTitle");
const prevMonth = document.querySelector("#prevMonth");
const nextMonth = document.querySelector("#nextMonth");
const todayButton = document.querySelector("#todayButton");
const weekdayRow = document.querySelector("#weekdayRow");
const calendarGrid = document.querySelector("#calendarGrid");
const dayEditorTitle = document.querySelector("#dayEditorTitle");
const clearDayButton = document.querySelector("#clearDayButton");
const enableAlertsMainButton = document.querySelector("#enableAlertsMainButton");
const testMacAlertButton = document.querySelector("#testMacAlertButton");
const alertStatusText = document.querySelector("#alertStatusText");
const diaryInput = document.querySelector("#diaryInput");
const planForm = document.querySelector("#planForm");
const planTimeInput = document.querySelector("#planTimeInput");
const planTextInput = document.querySelector("#planTextInput");
const planList = document.querySelector("#planList");
const plansDoneText = document.querySelector("#plansDoneText");
const planMessage = document.querySelector("#planMessage");
const reminderForm = document.querySelector("#reminderForm");
const reminderTimeInput = document.querySelector("#reminderTimeInput");
const reminderTextInput = document.querySelector("#reminderTextInput");
const reminderList = document.querySelector("#reminderList");
const remindersDoneText = document.querySelector("#remindersDoneText");
const reminderMessage = document.querySelector("#reminderMessage");
const dietGoal = document.querySelector("#dietGoal");
const waterInput = document.querySelector("#waterInput");
const breakfastInput = document.querySelector("#breakfastInput");
const lunchInput = document.querySelector("#lunchInput");
const dinnerInput = document.querySelector("#dinnerInput");
const snackInput = document.querySelector("#snackInput");
const notificationStack = document.querySelector("#notificationStack");
const alertButtons = [enableAlertsButton, enableAlertsMainButton].filter(Boolean);
let nativeAlertStatus = "unknown";

renderLogin();
planForm.noValidate = true;
reminderForm.noValidate = true;
planTimeInput.setCustomValidity("");
reminderTimeInput.setCustomValidity("");
window.mycalendarNativeAlertStatus = (status) => {
  nativeAlertStatus = status || "unknown";
  renderAlertButton();
};

loginForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const user = getSelectedUser();

  if (!user) {
    setLoginMessage("Choose a profile first.");
    return;
  }

  if (user.password && passwordInput.value !== user.password) {
    setLoginMessage("That password did not match. Try the hint button.");
    passwordInput.select();
    return;
  }

  activeUserId = user.id;
  state.activeUserId = user.id;
  saveState();
  loginMessage.textContent = "";
  passwordInput.value = "";
  hintBubble.classList.add("hidden");
  enterApp();
});

hintButton.addEventListener("click", () => {
  const user = getSelectedUser();
  if (!user) {
    return;
  }
  hintText.textContent = user.hint || "No hint saved.";
  hintBubble.classList.toggle("hidden");
});

removeProfileButton.addEventListener("click", () => {
  const user = getSelectedUser();
  if (!user) {
    return;
  }

  if (user.password && passwordInput.value !== user.password) {
    setLoginMessage("Type this profile's password first, then remove it.");
    passwordInput.focus();
    return;
  }

  state.users = state.users.filter((candidate) => candidate.id !== user.id);
  if (state.activeUserId === user.id) {
    state.activeUserId = null;
  }
  selectedUserId = state.users[0]?.id || null;
  passwordInput.value = "";
  hintBubble.classList.add("hidden");
  saveState();
  renderLogin();
});

loginImageInput.addEventListener("change", async () => {
  const user = getSelectedUser();
  const file = loginImageInput.files?.[0];
  if (!user || !file) {
    return;
  }

  user.avatar = await readImageFile(file);
  loginImageInput.value = "";
  saveState();
  renderLogin();
});

createUserForm.addEventListener("submit", (event) => {
  event.preventDefault();

  if (state.users.length >= 3) {
    setCreateMessage("You already have 3 profiles.");
    return;
  }

  const name = newUserName.value.trim();
  const password = newUserPassword.value;
  const hint = newUserHint.value.trim();

  if (!name) {
    setCreateMessage("Add a profile name first.");
    return;
  }

  const user = {
    id: crypto.randomUUID ? crypto.randomUUID() : String(Date.now()),
    name,
    password,
    hint,
    avatar: pendingNewUserAvatar,
    calendarMode: "european",
    weather: defaultWeather(),
    entries: {}
  };

  state.users.push(user);
  state.activeUserId = user.id;
  selectedUserId = user.id;
  saveState();

  newUserName.value = "";
  newUserPassword.value = "";
  newUserHint.value = "";
  newUserImage.value = "";
  pendingNewUserAvatar = "";
  setCreateMessage("");
  renderLogin();
  selectUser(user.id);
});

newUserImage.addEventListener("change", async () => {
  const file = newUserImage.files?.[0];
  pendingNewUserAvatar = file ? await readImageFile(file) : "";
});

calendarMode.addEventListener("change", () => {
  const user = getActiveUser();
  user.calendarMode = calendarMode.value;
  saveState();
  refreshTimeInputs();
  renderCalendar();
  renderSelectedDay();
  renderWeather();
  refreshWeather({ quiet: true });
});

signOutButton.addEventListener("click", () => {
  activeUserId = null;
  state.activeUserId = null;
  saveState();
  appScreen.classList.add("hidden");
  loginScreen.classList.remove("hidden");
  renderLogin();
});

activeImageInput.addEventListener("change", async () => {
  const user = getActiveUser();
  const file = activeImageInput.files?.[0];
  if (!user || !file) {
    return;
  }

  user.avatar = await readImageFile(file);
  activeImageInput.value = "";
  saveState();
  renderActiveProfile();
});

weatherForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const user = getActiveUser();
  if (!user) {
    return;
  }

  user.weather.location = weatherLocationInput.value.trim() || "Kyiv";
  saveState();
  refreshWeather({ quiet: false });
});

alertButtons.forEach((button) => {
  button.addEventListener("click", handleEnableAlertsClick);
});

testMacAlertButton.addEventListener("click", () => {
  showDueNotification("Test Alert");
  if (alertStatusText) {
    alertStatusText.textContent = window.webkit?.messageHandlers?.mycalendarNotify
      ? "Sent a test alert. If no Apple banner appears, check System Settings > Notifications > MyCalendar."
      : "This browser can only show the in-app test card. Open MyCalendar.app for Apple banners.";
  }
});

async function handleEnableAlertsClick() {
  if (postNativeNotification({ type: "requestPermission" })) {
    setAlertButtons("Checking...", true);
    if (alertStatusText) {
      alertStatusText.textContent = "macOS should ask for permission. The button will update after you choose.";
    }
    return;
  }

  if (!("Notification" in window)) {
    renderAlertButton();
    return;
  }

  if (Notification.permission === "default") {
    await Notification.requestPermission();
  }

  renderAlertButton();
}

prevMonth.addEventListener("click", () => {
  viewDate = new Date(viewDate.getFullYear(), viewDate.getMonth() - 1, 1);
  renderCalendar();
});

nextMonth.addEventListener("click", () => {
  viewDate = new Date(viewDate.getFullYear(), viewDate.getMonth() + 1, 1);
  renderCalendar();
});

todayButton.addEventListener("click", () => {
  selectedDate = new Date();
  viewDate = startOfMonth(selectedDate);
  renderCalendar();
  renderSelectedDay();
});

clearDayButton.addEventListener("click", () => {
  const user = getActiveUser();
  const key = toDateKey(selectedDate);
  const entry = user.entries[key];
  if (entry) {
    [...(entry.plans || []), ...(entry.reminders || [])].forEach((item) => cancelNativeItemNotification(item.id));
  }
  delete user.entries[key];
  saveState();
  renderCalendar();
  renderSelectedDay();
});

diaryInput.addEventListener("input", () => {
  const entry = getSelectedEntry();
  entry.diary = diaryInput.value;
  saveState();
  renderCalendar();
});

planForm.addEventListener("submit", (event) => {
  event.preventDefault();
  addTask("plans", planTimeInput, planTextInput, planMessage);
});

reminderForm.addEventListener("submit", (event) => {
  event.preventDefault();
  addTask("reminders", reminderTimeInput, reminderTextInput, reminderMessage);
});

[dietGoal, waterInput, breakfastInput, lunchInput, dinnerInput, snackInput].forEach((input) => {
  input.addEventListener("input", saveDiet);
  input.addEventListener("change", saveDiet);
});

[planTimeInput, reminderTimeInput].forEach((input) => {
  input.addEventListener("input", () => {
    input.classList.remove("input-error");
    input.removeAttribute("aria-invalid");
    planMessage.textContent = "";
    reminderMessage.textContent = "";
  });
});

[planTextInput, reminderTextInput].forEach((input) => {
  input.addEventListener("input", () => {
    planMessage.textContent = "";
    reminderMessage.textContent = "";
  });
});

if (activeUserId && getActiveUser()) {
  enterApp();
}

function renderLogin() {
  profileCount.textContent = `${state.users.length}/3 users`;
  createUserButton.disabled = state.users.length >= 3;
  createUserForm.classList.toggle("hidden", state.users.length >= 3);
  userSlots.innerHTML = "";

  for (let index = 0; index < 3; index += 1) {
    const user = state.users[index];

    if (user) {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "user-card";
      button.classList.toggle("active", user.id === selectedUserId);
      button.innerHTML = `
        ${avatarMarkup(user)}
        <div>
          <strong>${escapeHtml(user.name)}</strong>
          <span>${escapeHtml(user.password ? "Password protected" : "No password")}</span>
        </div>
      `;
      button.addEventListener("click", () => selectUser(user.id));
      userSlots.append(button);
    } else {
      const slot = document.createElement("div");
      slot.className = "empty-slot";
      slot.textContent = "Empty profile";
      userSlots.append(slot);
    }
  }

  if (!selectedUserId && state.users.length > 0) {
    selectUser(state.users[0].id);
  } else {
    updateSelectedLoginUser();
  }
}

function selectUser(userId) {
  selectedUserId = userId;
  hintBubble.classList.add("hidden");
  passwordInput.value = "";
  loginMessage.textContent = "";
  updateSelectedLoginUser();

  document.querySelectorAll(".user-card").forEach((card, index) => {
    card.classList.toggle("active", state.users[index]?.id === userId);
  });

  window.setTimeout(() => passwordInput.focus(), 0);
}

function updateSelectedLoginUser() {
  const user = getSelectedUser();
  loginForm.classList.toggle("hidden", !user);

  if (!user) {
    return;
  }

  selectedPasswordPrompt.textContent = user.password ? "Type your password" : "No password set";
  passwordInput.placeholder = user.password ? "" : "Press arrow to enter";
  setAvatarElement(selectedAvatarFrame, user);
  selectedUserName.textContent = user.name;
  hintText.textContent = user.hint || "No hint saved.";
}

function enterApp() {
  const user = getActiveUser();
  if (!user) {
    return;
  }

  loginScreen.classList.add("hidden");
  appScreen.classList.remove("hidden");
  workspaceTitle.textContent = `${user.name}'s diary`;
  renderActiveProfile();
  calendarMode.value = user.calendarMode || "european";
  viewDate = startOfMonth(selectedDate);
  startClock();
  refreshTimeInputs();
  renderAlertButton();
  renderCalendar();
  renderSelectedDay();
  renderWeather();
  if (!user.weather?.forecast) {
    refreshWeather({ quiet: true });
  }
}

function renderActiveProfile() {
  const user = getActiveUser();
  if (!user) {
    return;
  }

  setAvatarElement(activeAvatarFrame, user);
  activeUserName.textContent = user.name;
}

function renderCalendar() {
  const user = getActiveUser();
  const mode = getMode();
  monthTitle.textContent = monthFormatter.format(viewDate);
  modeCaption.textContent = mode.caption;
  weekdayRow.innerHTML = "";
  calendarGrid.innerHTML = "";

  getWeekdays(mode.weekStart).forEach((day) => {
    const cell = document.createElement("div");
    cell.textContent = day;
    weekdayRow.append(cell);
  });

  const firstOfMonth = startOfMonth(viewDate);
  const offset = (firstOfMonth.getDay() - mode.weekStart + 7) % 7;
  const gridStart = new Date(firstOfMonth);
  gridStart.setDate(firstOfMonth.getDate() - offset);

  for (let index = 0; index < 42; index += 1) {
    const date = new Date(gridStart);
    date.setDate(gridStart.getDate() + index);
    const key = toDateKey(date);
    const entry = user.entries[key];
    const button = document.createElement("button");
    button.type = "button";
    button.className = "day-cell";
    button.classList.toggle("outside", date.getMonth() !== viewDate.getMonth());
    button.classList.toggle("selected", key === toDateKey(selectedDate));
    button.classList.toggle("today", key === toDateKey(new Date()));

    const note = entry?.diary?.trim() || "";
    const flags = buildFlags(entry);

    button.innerHTML = `
      <div class="cell-top">
        <span class="gregorian-day">${date.getDate()}</span>
        <span class="alternate-day">${escapeHtml(formatAlternateShort(date))}</span>
      </div>
      <div class="cell-note">${escapeHtml(note)}</div>
      <div class="cell-flags">${flags}</div>
    `;
    button.addEventListener("click", () => {
      selectedDate = new Date(date);
      if (date.getMonth() !== viewDate.getMonth()) {
        viewDate = startOfMonth(date);
      }
      renderCalendar();
      renderSelectedDay();
    });
    calendarGrid.append(button);
  }
}

function buildFlags(entry) {
  if (!entry) {
    return "";
  }

  const flags = [];
  if ((entry.plans || []).length) {
    flags.push(`<span class="flag">${entry.plans.length}P</span>`);
  }
  if ((entry.reminders || []).length) {
    flags.push(`<span class="flag reminder">${entry.reminders.length}R</span>`);
  }
  if (hasDiet(entry.diet)) {
    flags.push(`<span class="flag diet">Diet</span>`);
  }
  return flags.join("");
}

function renderSelectedDay() {
  const entry = getSelectedEntry();
  const heading = dateHeadingFormatter.format(selectedDate);
  selectedDateHeading.textContent = heading;
  dayEditorTitle.textContent = heading;
  alternateDate.textContent = formatAlternateLong(selectedDate);
  diaryInput.value = entry.diary || "";

  const plans = entry.plans || [];
  const reminders = entry.reminders || [];
  planCount.textContent = String(plans.length);
  reminderCount.textContent = String(reminders.length);
  waterCount.textContent = String(Number(entry.diet?.water || 0));

  renderTasks("plans", planList, plans, plansDoneText);
  renderTasks("reminders", reminderList, reminders, remindersDoneText);
  renderDiet(entry.diet || defaultDiet());
  renderUpcoming();
}

function renderTasks(type, container, items, statusLabel) {
  container.innerHTML = "";
  const done = items.filter((item) => item.done).length;
  statusLabel.textContent = `${done} done`;

  if (!items.length) {
    const empty = document.createElement("div");
    empty.className = "empty-state";
    empty.textContent = type === "plans" ? "No plans yet." : "No reminders yet.";
    container.append(empty);
    return;
  }

  items
    .slice()
    .sort(sortByTime)
    .forEach((item) => {
      const row = document.createElement("div");
      row.className = "task-row";
      row.classList.toggle("done", item.done);

      const checkbox = document.createElement("input");
      checkbox.type = "checkbox";
      checkbox.checked = Boolean(item.done);
      checkbox.setAttribute("aria-label", `Mark ${item.text} done`);
      checkbox.addEventListener("change", () => {
        item.done = checkbox.checked;
        if (item.done) {
          cancelNativeItemNotification(item.id);
        } else {
          scheduleNativeItemNotification(item, type, toDateKey(selectedDate));
        }
        saveState();
        renderCalendar();
        renderSelectedDay();
      });

      const text = document.createElement("div");
      text.className = "task-text";
      const time = item.time ? `<strong>${escapeHtml(formatTaskTime(item.time))}</strong>` : "";
      text.innerHTML = `${time}<span>${escapeHtml(item.text)}</span>`;

      const remove = document.createElement("button");
      remove.type = "button";
      remove.className = "delete-button";
      remove.setAttribute("aria-label", `Delete ${item.text}`);
      remove.textContent = "x";
      remove.addEventListener("click", () => {
        const entry = getSelectedEntry();
        cancelNativeItemNotification(item.id);
        entry[type] = (entry[type] || []).filter((candidate) => candidate.id !== item.id);
        saveState();
        renderCalendar();
        renderSelectedDay();
      });

      row.append(checkbox, text, remove);
      container.append(row);
    });
}

function renderDiet(diet) {
  dietGoal.value = diet.goal || "balanced";
  waterInput.value = Number(diet.water || 0);
  breakfastInput.value = diet.breakfast || "";
  lunchInput.value = diet.lunch || "";
  dinnerInput.value = diet.dinner || "";
  snackInput.value = diet.snack || "";
}

function renderUpcoming() {
  const user = getActiveUser();
  const todayKey = toDateKey(new Date());
  const reminders = Object.entries(user.entries)
    .flatMap(([dateKey, entry]) => {
      return (entry.reminders || []).map((reminder) => ({ ...reminder, dateKey }));
    })
    .filter((reminder) => !reminder.done && reminder.dateKey >= todayKey)
    .sort((a, b) => `${a.dateKey} ${a.time}`.localeCompare(`${b.dateKey} ${b.time}`))
    .slice(0, 6);

  upcomingList.innerHTML = "";

  if (!reminders.length) {
    const empty = document.createElement("div");
    empty.className = "empty-state";
    empty.textContent = "No upcoming reminders.";
    upcomingList.append(empty);
    return;
  }

  reminders.forEach((reminder) => {
    const item = document.createElement("div");
    item.className = "upcoming-item";
    const date = parseDateKey(reminder.dateKey);
    const reminderTime = reminder.time ? ` at ${escapeHtml(formatTaskTime(reminder.time))}` : "";
    item.innerHTML = `
      <strong>${escapeHtml(reminder.text)}</strong>
      <span>${escapeHtml(dateHeadingFormatter.format(date))}${reminderTime}</span>
    `;
    upcomingList.append(item);
  });
}

function startClock() {
  updateClock();
  if (clockTimer) {
    return;
  }

  clockTimer = window.setInterval(updateClock, 1000);
}

function updateClock() {
  const user = getActiveUser();
  if (!user) {
    return;
  }

  const now = new Date();
  const timeText = formatClockTime(now);
  const minuteAngle = (now.getMinutes() + now.getSeconds() / 60) * 6 - 90;
  const hourAngle = ((now.getHours() % 12) + now.getMinutes() / 60) * 30 - 90;

  clockText.textContent = timeText;
  digitalClock.textContent = timeText;
  clockDate.textContent = new Intl.DateTimeFormat("en", {
    weekday: "short",
    month: "short",
    day: "numeric"
  }).format(now);
  clockMinuteHand.style.setProperty("--angle", `${minuteAngle}deg`);
  clockHourHand.style.setProperty("--angle", `${hourAngle}deg`);
  refreshTimeInputs(now);
  checkDueItems(now);
}

function formatClockTime(date) {
  const americanTime = getActiveUser()?.calendarMode === "northAmerican";
  return new Intl.DateTimeFormat(americanTime ? "en-US" : "en-GB", {
    hour: americanTime ? "numeric" : "2-digit",
    minute: "2-digit",
    hour12: americanTime
  })
    .format(date)
    .replace(/\u202f/g, " ");
}

function refreshTimeInputs(now = new Date()) {
  const americanTime = getActiveUser()?.calendarMode === "northAmerican";
  const currentTime = formatMinutesAsTime(now.getHours() * 60 + now.getMinutes());
  const placeholder = americanTime ? formatTaskTime(currentTime) : currentTime;
  planTimeInput.placeholder = placeholder;
  reminderTimeInput.placeholder = placeholder;
  planTimeInput.title = americanTime ? `Use ${placeholder} or ${currentTime}.` : `Use ${placeholder}.`;
  reminderTimeInput.title = americanTime ? `Use ${placeholder} or ${currentTime}.` : `Use ${placeholder}.`;
}

function normalizeTaskTime(value) {
  const minutes = parseTimeToMinutes(value);
  return minutes === null ? null : formatMinutesAsTime(minutes);
}

function parseTimeToMinutes(value) {
  const trimmed = String(value || "").trim();
  if (!trimmed) {
    return null;
  }

  const twelveHourMatch = trimmed.match(/^(\d{1,2})(?:[:.]?([0-5]\d))?\s*([ap])\.?m?\.?$/i);
  if (twelveHourMatch) {
    let hours = Number(twelveHourMatch[1]);
    const minutes = Number(twelveHourMatch[2] || 0);
    const marker = twelveHourMatch[3].toLowerCase();
    if (hours < 1 || hours > 12) {
      return null;
    }
    if (marker === "p" && hours !== 12) {
      hours += 12;
    }
    if (marker === "a" && hours === 12) {
      hours = 0;
    }
    return hours * 60 + minutes;
  }

  const compactTimeMatch = trimmed.match(/^(\d{3,4})$/);
  if (compactTimeMatch) {
    const digits = compactTimeMatch[1];
    const hours = Number(digits.slice(0, -2));
    const minutes = Number(digits.slice(-2));
    if (hours > 23 || minutes > 59) {
      return null;
    }
    return hours * 60 + minutes;
  }

  const twentyFourHourMatch = trimmed.match(/^(\d{1,2})[:.]([0-5]\d)$/);
  if (twentyFourHourMatch) {
    const hours = Number(twentyFourHourMatch[1]);
    const minutes = Number(twentyFourHourMatch[2]);
    if (hours > 23) {
      return null;
    }

    return hours * 60 + minutes;
  }

  const hourOnlyMatch = trimmed.match(/^(\d{1,2})$/);
  if (!hourOnlyMatch) {
    return null;
  }

  const hours = Number(hourOnlyMatch[1]);
  if (hours > 23) {
    return null;
  }

  return hours * 60;
}

function formatMinutesAsTime(minutes) {
  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;
  return `${String(hours).padStart(2, "0")}:${String(mins).padStart(2, "0")}`;
}

function formatTaskTime(value) {
  const minutes = parseTimeToMinutes(value);
  if (minutes === null) {
    return value || "";
  }

  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;
  const americanTime = getActiveUser()?.calendarMode === "northAmerican";
  if (!americanTime) {
    return formatMinutesAsTime(minutes);
  }

  return new Intl.DateTimeFormat("en-US", {
    hour: "numeric",
    minute: "2-digit",
    hour12: true
  })
    .format(new Date(2000, 0, 1, hours, mins))
    .replace(/\u202f/g, " ");
}

function checkDueItems(now) {
  const user = getActiveUser();
  if (!user) {
    return;
  }

  const todayKey = toDateKey(now);
  const entry = user.entries[todayKey];
  if (!entry) {
    return;
  }

  const nowMinutes = now.getHours() * 60 + now.getMinutes();
  let changed = false;

  [
    ["plans", "Plan"],
    ["reminders", "Reminder"]
  ].forEach(([type, fallbackName]) => {
    (entry[type] || []).forEach((item) => {
      if (item.done || parseTimeToMinutes(item.time) !== nowMinutes) {
        return;
      }

      const notifiedAt = `${todayKey} ${formatMinutesAsTime(nowMinutes)}`;
      if (item.notifiedAt === notifiedAt) {
        return;
      }

      item.notifiedAt = notifiedAt;
      changed = true;
      showDueNotification(item.text || fallbackName);
    });
  });

  if (changed) {
    saveState();
  }
}

function showDueNotification(notificationName) {
  showAppNotification(notificationName);
  playAlertSound();
  const body = `Your ${notificationName} notification is due now!`;

  if (postNativeNotification({ type: "due", title: "MyCalendar", body })) {
    return;
  }

  if ("Notification" in window && Notification.permission === "granted") {
    try {
      new Notification("MyCalendar", {
        body,
        icon: "icon.png"
      });
    } catch (error) {
      renderAlertButton();
    }
  }
}

function playAlertSound() {
  const AudioContextClass = window.AudioContext || window.webkitAudioContext;
  if (!AudioContextClass) {
    return;
  }

  try {
    const context = new AudioContextClass();
    const firstTone = context.createOscillator();
    const secondTone = context.createOscillator();
    const gain = context.createGain();
    firstTone.type = "square";
    secondTone.type = "square";
    firstTone.frequency.value = 880;
    secondTone.frequency.value = 660;
    gain.gain.setValueAtTime(0.0001, context.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.12, context.currentTime + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.0001, context.currentTime + 0.55);
    firstTone.connect(gain);
    secondTone.connect(gain);
    gain.connect(context.destination);
    firstTone.start(context.currentTime);
    firstTone.stop(context.currentTime + 0.22);
    secondTone.start(context.currentTime + 0.25);
    secondTone.stop(context.currentTime + 0.55);
  } catch (error) {
    return;
  }
}

function scheduleNativeItemNotification(item, type, dateKey) {
  if (!item.time || !postNativeNotification) {
    return;
  }

  const dueDate = taskDueDate(dateKey, item.time);
  if (!dueDate || dueDate.getTime() <= Date.now() + 1000) {
    return;
  }

  const label = type === "plans" ? "Plan" : "Reminder";
  postNativeNotification({
    type: "schedule",
    id: item.id,
    title: "MyCalendar",
    body: `Your ${item.text || label} notification is due now!`,
    dateKey,
    time: item.time
  });
}

function cancelNativeItemNotification(itemId) {
  if (!itemId) {
    return;
  }

  postNativeNotification({
    type: "cancel",
    id: itemId
  });
}

function taskDueDate(dateKey, time) {
  const minutes = parseTimeToMinutes(time);
  if (minutes === null) {
    return null;
  }

  const date = parseDateKey(dateKey);
  date.setHours(Math.floor(minutes / 60), minutes % 60, 0, 0);
  return date;
}

function postNativeNotification(payload) {
  const handler = window.webkit?.messageHandlers?.mycalendarNotify;
  if (!handler) {
    return false;
  }

  try {
    handler.postMessage(payload);
    return true;
  } catch (error) {
    return false;
  }
}

function showAppNotification(notificationName) {
  if (!notificationStack) {
    return;
  }

  const card = document.createElement("div");
  card.className = "notification-card";
  card.innerHTML = `
    <strong>MyCalendar</strong>
    <p>Your <em>${escapeHtml(notificationName)}</em> notification is due now!</p>
    <button class="notification-close" type="button" aria-label="Dismiss notification">x</button>
  `;

  const closeButton = card.querySelector(".notification-close");
  closeButton.addEventListener("click", () => card.remove());
  notificationStack.append(card);
  window.setTimeout(() => card.remove(), 14000);
}

function renderAlertButton() {
  if (!alertButtons.length) {
    return;
  }

  if (window.webkit?.messageHandlers?.mycalendarNotify) {
    if (nativeAlertStatus === "authorized" || nativeAlertStatus === "provisional") {
      setAlertButtons("Mac alerts on", true);
      testMacAlertButton.disabled = false;
      if (alertStatusText) {
        alertStatusText.textContent = "Apple Notification Center banners are allowed. Use Test alert to check sound/banner.";
      }
      return;
    }

    if (nativeAlertStatus === "denied") {
      setAlertButtons("Mac alerts blocked", true);
      testMacAlertButton.disabled = false;
      if (alertStatusText) {
        alertStatusText.textContent = "macOS blocked banners. Turn on MyCalendar in System Settings > Notifications.";
      }
      return;
    }

    setAlertButtons("Enable Mac alerts", false);
    testMacAlertButton.disabled = false;
    if (alertStatusText) {
      alertStatusText.textContent = "Click Enable Mac alerts, then press Test alert to check the banner and sound.";
    }
    return;
  }

  if (alertStatusText) {
    alertStatusText.textContent = "You are in the browser page. Open MyCalendar.app from Documents/MyGames/MyCalendar for Apple banners.";
  }

  setAlertButtons("Mac app only", true);
  testMacAlertButton.disabled = false;
}

function setAlertButtons(text, disabled) {
  alertButtons.forEach((button) => {
    button.textContent = text;
    button.disabled = disabled;
  });
}

function renderWeather() {
  const user = getActiveUser();
  if (!user) {
    return;
  }

  user.weather = normalizeWeather(user.weather);
  const forecast = user.weather.forecast;
  const desiredUnit = getTemperatureUnit();
  weatherLocationInput.value = user.weather.location || "Kyiv";
  weatherUnit.textContent = temperatureMark(forecast?.unit || desiredUnit);

  if (!forecast) {
    weatherIcon.textContent = "?";
    weatherIcon.dataset.kind = "unknown";
    weatherCondition.textContent = "Weather not loaded";
    weatherMeta.textContent = "Type a city and refresh.";
    weatherTemp.textContent = "--";
    weatherForecast.innerHTML = "";
    weatherMessage.textContent = "";
    updateClock();
    return;
  }

  const current = forecast.current;
  const decoded = describeWeather(current.weatherCode);
  weatherIcon.textContent = weatherSymbol(decoded.kind);
  weatherIcon.dataset.kind = decoded.kind;
  weatherCondition.textContent = decoded.label;
  weatherMeta.textContent = `${forecast.place} ${formatWeatherTime(forecast.updatedAt)}`;
  weatherTemp.textContent = Math.round(current.temperature);

  weatherForecast.innerHTML = "";
  forecast.daily.slice(0, 5).forEach((day) => {
    const decodedDay = describeWeather(day.weatherCode);
    const tile = document.createElement("div");
    tile.className = "forecast-tile";
    tile.innerHTML = `
      <strong>${escapeHtml(shortDayFormatter.format(parseDateKey(day.date)))}</strong>
      <span class="mini-weather" data-kind="${escapeHtml(decodedDay.kind)}">${escapeHtml(weatherSymbol(decodedDay.kind))}</span>
      <span>${Math.round(day.max)}${temperatureMark(forecast.unit)} / ${Math.round(day.min)}${temperatureMark(forecast.unit)}</span>
    `;
    weatherForecast.append(tile);
  });

  if (forecast.unit !== desiredUnit) {
    weatherMessage.textContent = `Refresh for ${desiredUnit === "fahrenheit" ? "Fahrenheit" : "Celsius"}.`;
  } else {
    weatherMessage.textContent = "";
  }
  updateClock();
}

async function refreshWeather({ quiet } = { quiet: false }) {
  const user = getActiveUser();
  if (!user) {
    return;
  }

  user.weather = normalizeWeather(user.weather);
  const location = weatherLocationInput.value.trim() || user.weather.location || "Kyiv";
  const unit = getTemperatureUnit();

  if (!quiet) {
    weatherMessage.textContent = "Refreshing weather...";
  }

  try {
    const place = await geocodeLocation(location);
    const forecast = await fetchForecast(place, unit);
    user.weather = {
      location: place.name,
      latitude: place.latitude,
      longitude: place.longitude,
      timezone: forecast.timezone,
      forecast
    };
    saveState();
    renderWeather();
  } catch (error) {
    if (!quiet) {
      weatherMessage.textContent = "Could not reach weather right now.";
    }
    renderWeather();
  }
}

async function geocodeLocation(location) {
  const response = await fetch(
    `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(location)}&count=1&language=en&format=json`
  );
  if (!response.ok) {
    throw new Error("Geocoding failed");
  }

  const data = await response.json();
  const place = data.results?.[0];
  if (!place) {
    throw new Error("Place not found");
  }

  return {
    name: [place.name, place.country_code].filter(Boolean).join(", "),
    latitude: place.latitude,
    longitude: place.longitude
  };
}

async function fetchForecast(place, unit) {
  const params = new URLSearchParams({
    latitude: place.latitude,
    longitude: place.longitude,
    current: "temperature_2m,weather_code,is_day",
    daily: "weather_code,temperature_2m_max,temperature_2m_min",
    forecast_days: "5",
    temperature_unit: unit,
    timezone: "auto"
  });
  const response = await fetch(`https://api.open-meteo.com/v1/forecast?${params.toString()}`);
  if (!response.ok) {
    throw new Error("Forecast failed");
  }

  const data = await response.json();
  return {
    place: place.name,
    unit,
    timezone: data.timezone || "",
    updatedAt: new Date().toISOString(),
    current: {
      temperature: data.current?.temperature_2m ?? 0,
      weatherCode: data.current?.weather_code ?? 0
    },
    daily: (data.daily?.time || []).map((date, index) => ({
      date,
      weatherCode: data.daily.weather_code?.[index] ?? 0,
      max: data.daily.temperature_2m_max?.[index] ?? 0,
      min: data.daily.temperature_2m_min?.[index] ?? 0
    }))
  };
}

function describeWeather(code) {
  const [label, kind] = weatherCodes[code] || ["Mixed", "cloud"];
  return { label, kind };
}

function weatherSymbol(kind) {
  return {
    sun: "Sunny",
    cloud: "Cloudy",
    fog: "Foggy",
    rain: "Rainy",
    snow: "Snow",
    storm: "Storm"
  }[kind] || "Weather";
}

function getTemperatureUnit() {
  const user = getActiveUser();
  return user?.calendarMode === "northAmerican" ? "fahrenheit" : "celsius";
}

function temperatureMark(unit = getTemperatureUnit()) {
  return unit === "fahrenheit" ? "F" : "C";
}

function formatWeatherTime(value) {
  if (!value) {
    return "";
  }

  return `forecast updated ${formatClockTime(new Date(value))}`;
}

function addTask(type, timeInput, textInput, messageElement) {
  const text = textInput.value.trim();
  const time = normalizeTaskTime(timeInput.value);

  timeInput.classList.remove("input-error");
  timeInput.removeAttribute("aria-invalid");
  messageElement.textContent = "";

  if (timeInput.value.trim() && time === null) {
    timeInput.classList.add("input-error");
    timeInput.setAttribute("aria-invalid", "true");
    messageElement.textContent = "Use a time like 17:51, 1751, or 5:51 PM.";
    timeInput.focus();
    return;
  }

  if (!text) {
    messageElement.textContent = "Write the plan or reminder text first.";
    textInput.focus();
    return;
  }

  const entry = getSelectedEntry();
  const id = crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random()}`;
  const item = {
    id,
    time,
    text,
    done: false,
    notifiedAt: ""
  };
  entry[type] = entry[type] || [];
  entry[type].push(item);
  scheduleNativeItemNotification(item, type, toDateKey(selectedDate));

  timeInput.value = "";
  textInput.value = "";
  messageElement.textContent = "";
  saveState();
  renderCalendar();
  renderSelectedDay();
  checkDueItems(new Date());
}

function saveDiet() {
  const entry = getSelectedEntry();
  entry.diet = {
    goal: dietGoal.value,
    water: clampNumber(Number(waterInput.value || 0), 0, 30),
    breakfast: breakfastInput.value.trim(),
    lunch: lunchInput.value.trim(),
    dinner: dinnerInput.value.trim(),
    snack: snackInput.value.trim()
  };
  saveState();
  renderCalendar();
  renderSelectedDay();
}

function getSelectedEntry() {
  const user = getActiveUser();
  const key = toDateKey(selectedDate);
  user.entries[key] = normalizeEntry(user.entries[key]);
  return user.entries[key];
}

function normalizeEntry(entry) {
  return {
    diary: entry?.diary || "",
    plans: Array.isArray(entry?.plans) ? entry.plans : [],
    reminders: Array.isArray(entry?.reminders) ? entry.reminders : [],
    diet: entry?.diet || defaultDiet()
  };
}

function defaultDiet() {
  return {
    goal: "balanced",
    water: 0,
    breakfast: "",
    lunch: "",
    dinner: "",
    snack: ""
  };
}

function defaultWeather() {
  return {
    location: "Kyiv",
    latitude: null,
    longitude: null,
    timezone: "",
    forecast: null
  };
}

function normalizeWeather(weather) {
  const fallback = defaultWeather();
  if (!weather || typeof weather !== "object") {
    return fallback;
  }

  return {
    location: typeof weather.location === "string" && weather.location ? weather.location : fallback.location,
    latitude: typeof weather.latitude === "number" ? weather.latitude : null,
    longitude: typeof weather.longitude === "number" ? weather.longitude : null,
    timezone: typeof weather.timezone === "string" ? weather.timezone : "",
    forecast: weather.forecast && typeof weather.forecast === "object" ? weather.forecast : null
  };
}

function hasDiet(diet) {
  if (!diet) {
    return false;
  }
  return Boolean(
    diet.goal !== "balanced" ||
      Number(diet.water || 0) > 0 ||
      diet.breakfast ||
      diet.lunch ||
      diet.dinner ||
      diet.snack
  );
}

function getSelectedUser() {
  return state.users.find((user) => user.id === selectedUserId) || null;
}

function getActiveUser() {
  return state.users.find((user) => user.id === activeUserId) || null;
}

function getMode() {
  const user = getActiveUser();
  return calendarModes[user?.calendarMode || "european"] || calendarModes.european;
}

function getWeekdays(start) {
  return Array.from({ length: 7 }, (_, index) => weekdayNames[(start + index) % 7]);
}

function startOfMonth(date) {
  return new Date(date.getFullYear(), date.getMonth(), 1);
}

function toDateKey(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function parseDateKey(key) {
  const [year, month, day] = key.split("-").map(Number);
  return new Date(year, month - 1, day);
}

function buildFormatter(locale, options) {
  try {
    return new Intl.DateTimeFormat(locale, options);
  } catch (error) {
    return null;
  }
}

function formatAlternateShort(date) {
  const mode = getMode();
  if (!mode.islamic || !islamicShortFormatter) {
    return "";
  }
  return islamicShortFormatter.format(date);
}

function formatAlternateLong(date) {
  const mode = getMode();
  if (!mode.islamic || !islamicFormatter) {
    return mode.caption;
  }
  return islamicFormatter.format(date);
}

function sortByTime(a, b) {
  const aMinutes = parseTimeToMinutes(a.time);
  const bMinutes = parseTimeToMinutes(b.time);
  return (aMinutes ?? 9999) - (bMinutes ?? 9999);
}

function clampNumber(value, min, max) {
  if (Number.isNaN(value)) {
    return min;
  }
  return Math.min(max, Math.max(min, value));
}

function avatarMarkup(user) {
  if (user.avatar) {
    return `<div class="avatar-frame has-image" aria-hidden="true"><img src="${escapeHtml(user.avatar)}" alt=""></div>`;
  }

  return `<div class="avatar-frame" aria-hidden="true"><span>${escapeHtml(getInitial(user.name))}</span></div>`;
}

function setAvatarElement(element, user) {
  element.classList.toggle("has-image", Boolean(user.avatar));
  element.innerHTML = user.avatar
    ? `<img src="${escapeHtml(user.avatar)}" alt="">`
    : `<span>${escapeHtml(getInitial(user.name))}</span>`;
}

function readImageFile(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.addEventListener("load", () => resizeImage(reader.result).then(resolve, reject));
    reader.addEventListener("error", reject);
    reader.readAsDataURL(file);
  });
}

function resizeImage(dataUrl) {
  return new Promise((resolve) => {
    const image = new Image();
    image.addEventListener("load", () => {
      const size = 256;
      const canvas = document.createElement("canvas");
      const context = canvas.getContext("2d");
      const shortestSide = Math.min(image.width, image.height);
      const sourceX = (image.width - shortestSide) / 2;
      const sourceY = (image.height - shortestSide) / 2;

      canvas.width = size;
      canvas.height = size;
      context.drawImage(image, sourceX, sourceY, shortestSide, shortestSide, 0, 0, size, size);
      resolve(canvas.toDataURL("image/jpeg", 0.86));
    });
    image.addEventListener("error", () => resolve(dataUrl));
    image.src = dataUrl;
  });
}

function getInitial(name) {
  return (name || "M").trim().charAt(0).toUpperCase() || "M";
}

function setLoginMessage(message) {
  loginMessage.textContent = message;
}

function setCreateMessage(message) {
  createMessage.textContent = message;
}

function loadState() {
  try {
    const parsed = JSON.parse(localStorage.getItem(STORAGE_KEY));
    if (parsed && Array.isArray(parsed.users)) {
      return {
        users: parsed.users.map(normalizeUser).slice(0, 3),
        activeUserId: parsed.activeUserId || null
      };
    }
  } catch (error) {
    localStorage.removeItem(STORAGE_KEY);
  }

  return {
    users: [],
    activeUserId: null
  };
}

function normalizeUser(user) {
  const calendarMode = user.calendarMode === "islamicTuesday" ? "islamicSaturday" : user.calendarMode;

  return {
    id: user.id || String(Date.now()),
    name: user.name || "User",
    password: user.password || "",
    hint: user.hint || "",
    avatar: typeof user.avatar === "string" ? user.avatar : "",
    calendarMode: calendarModes[calendarMode] ? calendarMode : "european",
    weather: normalizeWeather(user.weather),
    entries: user.entries && typeof user.entries === "object" ? user.entries : {}
  };
}

function saveState() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}
