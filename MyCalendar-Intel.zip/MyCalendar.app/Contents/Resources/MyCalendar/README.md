# MyCalendar

MyCalendar is a local, self-contained diary calendar for `Documents/MyGames/MyCalendar`.

Open `index.html` in a browser. It stores profiles, optional passwords, hints, profile icons, diary notes, plans, reminders, and diet notes in the browser's local storage on this computer.

Native macOS wrappers are included as `MyCalendar-Intel.app` and `MyCalendar-Apple-Silicon.app`.

## First version

- Up to 3 user profiles.
- Green Windows-XP-inspired password screen with optional passwords and password hints.
- Import Image controls for custom user icons.
- Islamic calendar mode with Saturday week start.
- European calendar mode with Monday week start.
- North American calendar mode with Sunday week start.
- Sidebar weather forecast with automatic Celsius/Fahrenheit switching by calendar mode.
- Built-in digital and two-hand analog clock next to the weather panel.
- Reminder due alerts with a MyCalendar notification message.
- Native macOS builds can show Apple Notification Center banners for due plans and reminders.
- Per-day diary, plans, reminders, and diet tracking.
